set names utf8;
use qy_community;

DROP TABLE IF EXISTS `t_user_level`;
DROP TABLE IF EXISTS `t_score_flow`;
DROP TABLE IF EXISTS `t_user_score_detail`;
DROP TABLE IF EXISTS `t_setting_level`;
DROP TABLE IF EXISTS `t_setting_score`;
DROP TABLE IF EXISTS `t_score_config`;

-- 用户等级表
CREATE TABLE `t_user_level` (
	`Fuser_id` varchar(32) NOT NULL,
	`Flevel` int(11) NOT NULL DEFAULT '0' COMMENT '当前等级',
	`Fscore` int(11) NOT NULL DEFAULT '0' COMMENT '当前积分',
	`Ftotal_score` int(11) NOT NULL DEFAULT '0' COMMENT '累计积分',
	`Fcreate_time` datetime DEFAULT NULL,
	`Fupdate_time` datetime DEFAULT NULL,
	PRIMARY KEY (`Fuser_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 日志流水记录表
CREATE TABLE `t_score_flow` (
	`Fid` int(11) NOT NULL AUTO_INCREMENT,
	`Fflow_id` varchar(32) NOT NULL COMMENT '唯一流水id',
	`Fuser_id` varchar(32) NOT NULL,
	`Fopcode` varchar(32) NOT NULL COMMENT '操作码',
	`Foption` varchar(255) DEFAULT NULL COMMENT '日志备注明细选项',
	`Fcreate_time` datetime DEFAULT NULL,
	`Fupdate_time` datetime DEFAULT NULL,
	PRIMARY KEY (`Fid`),
	UNIQUE KEY (`Fflow_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 积分变更明细记录表
CREATE TABLE `t_user_score_detail` (
	`Fid` int(11) NOT NULL AUTO_INCREMENT,
	`Fflow_id` varchar(32) NOT NULL COMMENT '唯一流水id',
	`Fuser_id` varchar(32) NOT NULL,
	`Fopcode` varchar(32) NOT NULL COMMENT '操作码',
	`Fscore` int(11) NOT NULL COMMENT '对应操作增加积分',
	`Fuser_level` tinyint(3) NOT NULL COMMENT '用户等级',
	`Fcreate_time` datetime DEFAULT NULL,
	`Fupdate_time` datetime DEFAULT NULL,
	PRIMARY KEY (`Fid`),
	UNIQUE KEY (`Fflow_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 等级设置表
CREATE TABLE `t_setting_level` (
	`Fid` int(11) NOT NULL AUTO_INCREMENT,
	`Flevel` tinyint(3) NOT NULL DEFAULT '0' COMMENT '等级',
	`Fname` varchar(32) DEFAULT NULL COMMENT '等级名称',
	`Fupgrade_score` int(11) NOT NULL DEFAULT '0' COMMENT '等级对应升级积分',
	`Fcreate_time` datetime DEFAULT NULL,
	`Fupdate_time` datetime DEFAULT NULL,
	PRIMARY KEY (`Fid`),
  UNIQUE KEY (`Flevel`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 积分设置表
CREATE TABLE `t_setting_score` (
	`Fid` int(11) NOT NULL AUTO_INCREMENT,
	`Fopcode` varchar(32) NOT NULL COMMENT '操作码',
	`Fname` varchar(32) NOT NULL COMMENT '操作名称',
	`Finstruction` varchar(64) NOT NULL DEFAULT '' COMMENT '操作说明',
	`Fscore` int(11) NOT NULL DEFAULT '0' COMMENT '操作对应积分',
	`Fstatus` tinyint(11) NOT NULL DEFAULT '0' COMMENT '状态码 0启用 1禁用',
	`Fcreate_time` datetime DEFAULT NULL,
	`Fupdate_time` datetime DEFAULT NULL,
	PRIMARY KEY (`Fid`),
	UNIQUE KEY (`Fopcode`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 配置表，每日上限配置
CREATE TABLE `t_score_config` (
	`Fid` int(11) NOT NULL AUTO_INCREMENT,
	`Fname` varchar(32) NOT NULL COMMENT '配置名称',
	`Finstruction` varchar(64) NOT NULL DEFAULT '' COMMENT '配置说明',
	`Fscore` int(11) NOT NULL DEFAULT '0' COMMENT '配置值',
	`Fcreate_time` datetime DEFAULT NULL,
	`Fupdate_time` datetime DEFAULT NULL,
	PRIMARY KEY (`Fid`),
	UNIQUE KEY (`Fname`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `t_score_config` (`Fname`, `Finstruction`, `Fscore`) VALUES
('dailyLimit', '每日经验上限', 100);

INSERT INTO `t_setting_level` (`Flevel`, `Fupgrade_score`) VALUES
(0, 10), (1, 50), (2, 60), (3, 90), (4, 120), (5, 150), (6, 180), (7, 210), (8, 240), (9, 270),
(10, 300), (11, 330), (12, 360), (13, 390), (14, 420), (15, 450), (16, 480), (17, 510), (18, 540), (19, 570),
(20, 600), (21, 630), (22, 660), (23, 690), (24, 720), (25, 750), (26, 780), (27, 810), (28, 840), (29, 870),
(30, 900), (31, 930), (32, 960), (33, 990), (34, 1020), (35, 1050), (36, 1080), (37, 1110), (38, 1140), (39, 1170),
(40, 1200), (41, 1230), (42, 1260), (43, 1290), (44, 1320), (45, 1350), (46, 1380), (47, 1410), (48, 1440), (49, 1470);

INSERT INTO `t_setting_score` (`Fopcode`, `Fname`, `Finstruction`, `Fscore`) VALUES
('liked', '被赞', '帖子被点赞', 20), ('post', '发帖', '帖子发布', 50),('reply', '回帖', '回复帖子', 10);