set NAMES utf8;
use db_community;

UPDATE tbl_bbs SET FCreateTime = '2017-08-09 16:15:12' WHERE FBbsId = 7;

