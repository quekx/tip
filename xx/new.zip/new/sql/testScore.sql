set names utf8;
use qy_community;

INSERT INTO `t_setting_score` (`Fopcode`, `Fname`, `Finstruction`, `Fscore`) VALUES
('liked', '被赞', '帖子被点赞', 20), ('post', '发帖', '帖子发布', 50),('reply', '回帖', '回复帖子', 10);