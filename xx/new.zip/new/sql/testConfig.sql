set names utf8;
use qy_community;

INSERT INTO `t_score_config` (`Fname`, `Finstruction`, `Fscore`) VALUES
('dailyLimit', '每日经验上限', 100);