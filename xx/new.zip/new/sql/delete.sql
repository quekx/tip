set names utf8;
use qy_community;


DROP TABLE `tbl_user_level`;

DROP TABLE `tbl_score_flow`;

DROP TABLE `tbl_user_score_detail`;

DROP TABLE `tbl_setting_level`;

DROP TABLE `tbl_setting_score`;
