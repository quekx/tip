set names utf8;
use qy_community;

ALTER TABLE `t_score_flow` CHANGE `Foption` `Foption` varchar(255) DEFAULT NULL COMMENT '日志备注明细选项';