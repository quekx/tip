set NAMES utf8;
use db_community;

UPDATE tbl_bbs SET FLogo = 'http://img1.gtimg.com/house/pics/hv1/64/214/2230/145060384.jpg' WHERE FBbsId = 5;

INSERT tbl_bbs (`FName`, `FLogo` ) VALUES
('猫片', 'http://img1.gtimg.com/house/pics/hv1/233/213/2230/145060298.jpg');