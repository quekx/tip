set NAMES utf8;
use db_community;

UPDATE tbl_bbs SET FServiceId = '1002' WHERE FBbsId = 7;

UPDATE tbl_bbs SET FLogo = 'http://img1.gtimg.com/house/pics/hv1/215/217/2230/145061300.png' WHERE FBbsId = 6;
