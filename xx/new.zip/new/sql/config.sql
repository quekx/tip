set names utf8;
use qy_community;

DROP TABLE IF EXISTS `t_score_config`;

CREATE TABLE `t_score_config` (
	`Fid` int(11) NOT NULL AUTO_INCREMENT,
	`Fname` varchar(32) NOT NULL COMMENT '配置名称',
	`Finstruction` varchar(64) NOT NULL DEFAULT '' COMMENT '配置说明',
	`Fscore` int(11) NOT NULL DEFAULT '0' COMMENT '配置值',
	`Fcreate_time` datetime DEFAULT NULL,
	`Fupdate_time` datetime DEFAULT NULL,
	PRIMARY KEY (`Fid`),
	UNIQUE KEY (`Fname`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;