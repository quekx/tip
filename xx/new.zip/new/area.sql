SET NAMES utf8;

DROP TABLE IF EXISTS `t_area_report`;

-- 地区记录
CREATE TABLE `t_area_report` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `uin` CHAR(20) DEFAULT NULL COMMENT 'QQ',
  `uid` CHAR(20) DEFAULT NULL COMMENT '企鹅社区全局用户ID',
  `openid` VARCHAR(32) DEFAULT NULL COMMENT '微信id',
  `area` VARCHAR(32) NOT NULL COMMENT '地区',
  `createtime` DATETIME NOT NULL,
  `updatetime` DATETIME NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;